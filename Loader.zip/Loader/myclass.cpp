#include <QQmlContext>
#include <QPluginLoader>

#include "myclass.h"
#include "MyInterface.h"
#include "myplugin.h"


MyClass::MyClass(QQmlApplicationEngine *pEngine)
{
    mEngine = pEngine;
    const QUrl url(QStringLiteral("qrc:/main.qml"));
    mEngine->rootContext()->setContextProperty("myClass", this);

    mEngine->load(url);
}

void MyClass::changeMessage()
{

    QPluginLoader loader("C:/Users/orhan/Documents/orhan/software/qtWorks/PluginApp_v2/Loader/debug/Plugin/Plugind.dll");
    QObject* instance = loader.instance();

    if (!instance) {
        qWarning() << "Failed to load plugin:" << loader.errorString();
    }

    MyPlugin *myPlugin = qobject_cast<MyPlugin*>(instance);
    if (!myPlugin) {
        qWarning() << "Failed to cast plugin instance";
    }

    qDebug() << "message changed";
}

void MyClass::changeColor()
{
    qDebug() << "color changed";
}
