#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlComponent>
#include <QQuickItem>
#include <QQmlProperty>


#include "myclass.h"

int main(int argc, char *argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif
    QGuiApplication app(argc, argv);

    QQmlApplicationEngine engine;
    MyClass myClass(&engine);
//    const QUrl url(QStringLiteral("qrc:/main.qml"));
//    engine.load(url);

    QObject *rootObject = engine.rootObjects().first();
    QObject *rectangle = rootObject->findChild<QObject*>("myRectangleObject");

    if (rectangle)
    {
        QQmlProperty::write(rectangle, "color", "pink");
    }
    else
    {
        qWarning() << "Kein Kindobjekt mit dem Namen 'myRectangleObject' gefunden";
    }

    return app.exec();

}

