#ifndef MYCLASS_H
#define MYCLASS_H

#include <QObject>
#include <QQmlApplicationEngine>

class MyClass : public QObject
{
    Q_OBJECT
public:
    MyClass(QQmlApplicationEngine* pEngine);
    QQmlApplicationEngine* mEngine = nullptr;

    Q_INVOKABLE void changeMessage();
    Q_INVOKABLE void changeColor();
};

#endif // MYCLASS_H
