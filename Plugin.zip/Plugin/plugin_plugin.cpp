#include "plugin_plugin.h"

#include "myplugin.h"

#include <qqml.h>

void PluginPlugin::registerTypes(const char *uri)
{
    // @uri Plugin
    qmlRegisterType<MyPlugin>(uri, 1, 0, "MyPlugin");
}

