#ifndef MYINTERFACE_H
#define MYINTERFACE_H

#include <QObject>

class MyInterface : public QObject
{
    Q_OBJECT
public:
    explicit MyInterface(QObject *parent = nullptr) : QObject(parent) {}

    virtual void run(const QString &pParam) = 0;
    QString message = "this message comes from interface";

signals:
    void runInvoked(const QString &pParam);
};

#define MyInterface_iid "org.example.MyInterface"
Q_DECLARE_INTERFACE(MyInterface, MyInterface_iid)

#endif // MYINTERFACE_H
