#ifndef MYPLUGIN_H
#define MYPLUGIN_H

#include <QtQuick>
#include "MyInterface.h"

class MyPlugin : public MyInterface
{
    Q_OBJECT
   // Q_PLUGIN_METADATA(IID MyInterface_iid)
    Q_INTERFACES(MyInterface)
    QML_ELEMENT
    Q_DISABLE_COPY(MyPlugin)
public:
    explicit MyPlugin(QQuickItem *parent = nullptr);
    ~MyPlugin();

    Q_INVOKABLE void run(const QString& pParam) override;
    Q_INVOKABLE void test(const QString& pParam);

signals:
    void runInvoked(const QString& pParam);
    void testInvoked(const QString& pParam);
};

#endif // MYPLUGIN_H
