/****************************************************************************
** Generated QML type registration code
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <QtQml/qqml.h>
#include <QtQml/qqmlmoduleregistration.h>

#include <myplugin.h>

void qml_register_types_Plugin()
{
    qmlRegisterTypesAndRevisions<MyPlugin>("Plugin", 1);
    qmlRegisterModule("Plugin", 1, 0);
}

static const QQmlModuleRegistration registration("Plugin", 1, qml_register_types_Plugin);
