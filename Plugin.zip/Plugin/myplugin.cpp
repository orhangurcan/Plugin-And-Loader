#include "myplugin.h"

MyPlugin::MyPlugin(QQuickItem *parent)
{
}

MyPlugin::~MyPlugin()
{
}

void MyPlugin::run(const QString& pParam)
{
    qDebug() << "runInvoked" << "is sent";
    qDebug() << pParam << message;
    emit runInvoked(pParam);
}

void MyPlugin::test(const QString &pParam)
{
    qDebug() << "testInvoked" << "is sent";
    qDebug() << pParam << message;
    emit testInvoked(pParam);
}
